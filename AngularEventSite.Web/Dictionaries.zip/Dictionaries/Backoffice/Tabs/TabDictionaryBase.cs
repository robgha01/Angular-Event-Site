﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TabDictionaryBase.cs" company="BlueLeet">
//   Copyright (C) BlueLeet - All Rights Reserved 
//   Unauthorized copying of this file, via any medium is strictly prohibited
//   Proprietary and confidential
// </copyright>
// <summary>
//   The tab dictionary base.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ClaremontExplore.Web.Dictionaries.Backoffice.Tabs
{
    using BlueLeet.UCodeFirst.Dictionaries;

    using JetBrains.Annotations;

    using ClaremontExplore.Web.Services;

    /// <summary>
    /// The tab dictionary base.
    /// </summary>
    [UsedImplicitly]
    public class TabDictionaryBase : DictionaryBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TabDictionaryBase"/> class.
        /// </summary>
        public TabDictionaryBase()
        {
            this.ParentKey = Constants.BackofficeDictionaryName;
        }

        /// <inheritdoc />
        public override string Resource { get; } = "Tabs";

        /// <inheritdoc />
        public override bool UseResourceName { get; } = true;
    }
}
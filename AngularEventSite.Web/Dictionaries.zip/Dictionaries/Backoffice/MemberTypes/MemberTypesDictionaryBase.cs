﻿namespace ClaremontExplore.Web.Dictionaries.Backoffice.MemberTypes
{
    using BlueLeet.UCodeFirst.Dictionaries;

    using JetBrains.Annotations;

    using ClaremontExplore.Web.Dictionaries.Backoffice.ContentTypes;
    using ClaremontExplore.Web.Services;

    /// <summary>
    /// The MemberTypesDictionaryBase dictionary base.
    /// </summary>
    [UsedImplicitly]
    public class MemberTypesDictionaryBase : DictionaryBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BaseContentModelDictionaryBase"/> class.
        /// </summary>
        public MemberTypesDictionaryBase()
        {
            this.ParentKey = Constants.BackofficeDictionaryName;
        }

        /// <inheritdoc />
        public override string Resource { get; } = "MemberTypes";

        /// <inheritdoc />
        public override bool UseResourceName { get; } = true;
    }
}
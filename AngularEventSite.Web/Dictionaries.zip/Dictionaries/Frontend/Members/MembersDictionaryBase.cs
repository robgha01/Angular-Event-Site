﻿namespace ClaremontExplore.Web.Dictionaries.Frontend.Members
{
    using BlueLeet.UCodeFirst.Dictionaries;

    using JetBrains.Annotations;

    using ClaremontExplore.Web.Services;

    /// <summary>
    /// The MembersDictionaryBase dictionary base.
    /// </summary>
    [UsedImplicitly]
    public class MembersDictionaryBase : DictionaryBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MembersDictionaryBase"/> class.
        /// </summary>
        public MembersDictionaryBase()
        {
            this.ParentKey = Constants.FrontendDictionaryName;
        }

        /// <inheritdoc />
        public override string Resource { get; } = "Members";

        /// <inheritdoc />
        public override bool UseResourceName { get; } = true;
    }
}
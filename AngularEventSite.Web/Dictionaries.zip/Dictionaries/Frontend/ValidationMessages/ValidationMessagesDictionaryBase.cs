﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ValidationMessagesDictionaryBase.cs" company="BlueLeet">
//   Copyright (C) BlueLeet - All Rights Reserved 
//   Unauthorized copying of this file, via any medium is strictly prohibited
//   Proprietary and confidential
// </copyright>
// <summary>
//   The MembersDictionaryBase dictionary base.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ClaremontExplore.Web.Dictionaries.Frontend.ValidationMessages
{
    using BlueLeet.UCodeFirst.Dictionaries;

    using JetBrains.Annotations;

    using ClaremontExplore.Web.Services;

    /// <summary>
    /// The ValidationMessagesDictionaryBase dictionary base.
    /// </summary>
    [UsedImplicitly]
    public class ValidationMessagesDictionaryBase : DictionaryBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationMessagesDictionaryBase"/> class.
        /// </summary>
        public ValidationMessagesDictionaryBase()
        {
            this.ParentKey = Constants.FrontendDictionaryName;
        }

        /// <inheritdoc />
        public override string Resource { get; } = "ValidationMessages";

        /// <inheritdoc />
        public override bool UseResourceName { get; } = true;
    }
}
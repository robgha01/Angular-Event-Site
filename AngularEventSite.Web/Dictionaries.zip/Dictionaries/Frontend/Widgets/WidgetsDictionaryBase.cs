﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="WidgetsDictionaryBase.cs" company="BlueLeet">
//   Copyright (C) BlueLeet - All Rights Reserved
//   Unauthorized copying of this file, via any medium is strictly prohibited
//   Proprietary and confidential
// </copyright>
// <summary>
//   The WidgetsDictionaryBase dictionary base.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using BlueLeet.UCodeFirst.Dictionaries;
using JetBrains.Annotations;
using ClaremontExplore.Web.Services;

namespace ClaremontExplore.Web.Dictionaries.Frontend.Widgets
{
    /// <summary>
    /// The ComponentsDictionaryBase dictionary base.
    /// </summary>
    [UsedImplicitly]
    public class WidgetsDictionaryBase : DictionaryBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WidgetsDictionaryBase"/> class.
        /// </summary>
        public WidgetsDictionaryBase()
        {
            this.ParentKey = Constants.FrontendDictionaryName;
        }

        /// <inheritdoc />
        public override string Resource { get; } = "Widgets";

        /// <inheritdoc />
        public override bool UseResourceName { get; } = true;
    }
}
﻿import { Component, Inject, ChangeDetectionStrategy, NgZone, HostListener, Input, SecurityContext, ElementRef, QueryList, ViewChild, ContentChild, ContentChildren, ChangeDetectorRef, TemplateRef, ViewContainerRef, OnInit, AfterViewInit, AfterContentInit, OnChanges, SimpleChanges, ViewChildren } from "@angular/core";
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import { Response } from "@angular/http";
import { DomSanitizer } from "@angular/platform-browser";
import { TemplateBaseComponent } from "../abstraction/TemplateBaseComponent";
import { FileUploader, FileItem, ParsedResponseHeaders } from "ng2-file-upload";
import { ModalDirective } from "ng2-bootstrap/modal";
import { IMemberPayload } from "../../abstraction/IMemberPayload";
import { InlineEditorGroupComponent, InlineEditorState } from "../../blueleet/modules/inline-editor/inline-editor-group.component";
import * as bl from "../../blueleet";
import * as enums from "../../enums/";
import * as $ from "jquery";
import * as Rx from "rxjs/Rx";

const _ = require("lodash");
require("./next.png");
require("./prev.png");

export interface IPhoto {
    url: string;
    name: string;
    createDate: Date;
    id: number;
    displayName: string;
    hairColor: any;
    hairLength: any;
    colorType: any;
    texture: any;
    isApproved: boolean;
}

export interface IProfileEntity {
    user: any;
}

export interface IPhotoChange {
    controlIndex: number;
    photo: IPhoto;
}

export interface IGetPhotosPayload {
    items: IPhoto[];
    totalPages: number;
}

@Component({
    selector: "profile-panel",
    template: require("./templates/profile.html"),
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfileComponent extends TemplateBaseComponent implements OnInit, AfterContentInit {
    @ViewChild("photoModal") public photoModal: ModalDirective;
    @ViewChild("DefaultTemplate") defaultTemplate: TemplateRef<any>;
    @ViewChild(".pane-photos") photosPanelElement: ElementRef;
    @Input("user-id") id: number = null;
    profile: IProfileEntity;
    photos: IPhoto[];
    photosPageIndex: number = 1;
    photosTotalPages: number;
    currentEditingPhoto: IPhoto = null;
    currentPhotoIsVisible: boolean = true;
    currentImageIndex: number = 1;
    enableKeybordNav: boolean = false;
    profileForm: FormGroup;
    photosForm: FormGroup;
    avatarForm: FormGroup;
    photoChanges: IPhotoChange[] = [];
    isEditingPhoto: boolean = false;
    uploader: FileUploader = new FileUploader({ url: "/umbraco/api/Profile/UploadPhotos/", autoUpload: true, removeAfterUpload: true });
    busy: Promise<any>[] = [];
    showPhotoInfo: boolean = false;

    hairColors: string[];
    hairLengths: string[];
    colorTypes: string[];
    textures: string[];

    // ToDo: refactor into common directive or alert service.
    // {
    //    type: 'success',
    //    msg: `<strong>Well done!</strong> You successfully read this important alert message.`
    // },
    // {
    //    type: 'info',
    //    msg: `<strong>Heads up!</strong> This alert needs your attention, but it's not super important.`
    // },
    // {
    //    type: 'danger',
    //    msg: `<strong>Warning!</strong> Better check yourself, you're not looking too good.`
    // }
    alerts: any = [];

    modalAlerts: any = [];

    constructor(
        @Inject(ChangeDetectorRef) changeDetectorRef: ChangeDetectorRef,
        @Inject(ViewContainerRef) viewContainer: ViewContainerRef,
        @Inject(NgZone) private ngZone: NgZone,
        @Inject(FormBuilder) private formBuilder: FormBuilder,
        @Inject(FormBuilder) private sanitizer: DomSanitizer,
        @Inject(bl.UmbracoAjaxService) private umbracoAjaxService: bl.UmbracoAjaxService
    ) {
        super(changeDetectorRef, viewContainer);
        setInterval(() => {
            this.changeDetectorRef.markForCheck();
        }, 500);
    }

    toggleShowInfo() {
        this.showPhotoInfo = !this.showPhotoInfo;
    }

    approvePhoto(item: IPhoto = this.currentEditingPhoto) {
        this.umbracoAjaxService.post("Profile", "PhotoApprovalPost", { imageId: item.id, approve: true }).then((value: Response) => {
            if (value.status === 200) {
                this.currentEditingPhoto.isApproved = true;
            } else {
                this.modalAlerts.push({ type: "danger", msg: `${value.status}: Något gick fel.` });   
            }
        });
    }

    disapprovePhoto(item: IPhoto = this.currentEditingPhoto) {
        this.umbracoAjaxService.post("Profile", "PhotoApprovalPost", { imageId: item.id, approve: false }).then((value: Response) => {
            if (value.status === 200) {
                this.currentEditingPhoto.isApproved = false;
            } else {
                this.modalAlerts.push({ type: "danger", msg: `${value.status}: Något gick fel.` });
            }
        });
    }

    deletePhoto(item: IPhoto = this.currentEditingPhoto) {
        if (confirm(`Är du säker på att du vill radera ${item.displayName}?`)) {
            const promise = this.umbracoAjaxService.post("Profile", "DeletePhotoPost", { id: item.id }).then(() => {
                let index = this.photos.indexOf(item);
                this.photos.splice(index, 1);
                if (index % this.photos.length <= 1) {
                    const newPhoto = this.photos[index];
                    this.setCurrentEditingPhoto(newPhoto);
                } else {
                    this.closeModalPhoto();
                }
            });
            this.busy.push(promise);
        }
    }

    getSizedUrl(photo: IPhoto, width: number): string {
        if (Object.isNullOrUndefined(photo)) {
            return "";
        } else if (Object.isNullOrUndefined(photo.url)) {
            console.log(photo);
            return "";
        }

        return `${photo.url}?width=${width}`;
    }

    initPhotoChange(photo: IPhoto, controlIndex: number) {
        this.photoChanges.push({ photo: photo, controlIndex: controlIndex });

        // initialize our address
        return this.formBuilder.group({
            id: [photo.id],
            displayName: [photo.displayName, Validators.required],
            hairColor: [photo.hairColor],
            hairLength: [photo.hairLength],
            colorType: [photo.colorType],
            texture: [photo.texture]
        });
    }

    mapSelectFor(values: string[]) {
        return _.map(values,
            (item) => {
                return { value: item, text: item }
            });
    }

    isCurrentEditingPhoto(index: any): boolean {
        const foundItem: IPhotoChange = _.find(this.photoChanges, (o: IPhotoChange) => o.controlIndex === index);
        if (foundItem) {
            return foundItem.photo.id === this.currentEditingPhoto.id;
        }
        return false;
    }

    hasPhotoChangeFor(photo: IPhoto): boolean {
        const foundItem = _.find(this.photoChanges, (o: IPhotoChange) => o.photo.id === photo.id);
        if (foundItem) {
            return true;
        }
        return false;
    }

    addPhotoChange(photo: IPhoto) {
        if (this.hasPhotoChangeFor(photo)) {
            return;
        }

        // add address to the list
        const control = <FormArray>this.photosForm.controls['photoChanges'];
        control.push(this.initPhotoChange(photo, control.length));
    }

    removePhotoChange(photoId: number) {
        let control = <FormArray>this.photosForm.controls['photoChanges'];
        let changeIndex: number;

        this.photoChanges.forEach((value, index) => {
            if (value.photo.id === photoId) {
                const con = control.at(index);
                con.disable();
                changeIndex = index;
            }
        });

        if (changeIndex) {
            this.photoChanges.splice(changeIndex, 1);
        }
    }

    hasPages(startIndex: number = null) {
        let photoIndex = startIndex === null ? (this.photos === null ? 0 : this.photos.length) : startIndex;
        if (photoIndex === -1) {
            return true;
        }

        photoIndex += 1;
        if (photoIndex > this.photosTotalPages) {
            return false;
        }

        return true;
    }

    nextPhoto() {
        const self = this;
        self.currentPhotoIsVisible = false;
        let photoIndex = self.photos.indexOf(self.currentEditingPhoto) + 1;

        // modulus '%' keeps index within the bounds, while incrementing.
        if (photoIndex % this.photos.length === 0) {
            // check if we have any more pages to fetch.
            if (this.photosPageIndex % this.photosTotalPages === 0) {
                photoIndex = 0;
            }
        }

        self.getImage(photoIndex).then(value => {
            self.setCurrentEditingPhoto(value);
        });
    }

    prevPhoto() {
        const self = this;
        self.currentPhotoIsVisible = false;
        let photoIndex = self.photos.indexOf(self.currentEditingPhoto) - 1;
        if (photoIndex === -1) {
            photoIndex = self.photos.length - 1;
        }

        self.getImage(photoIndex).then(value => {
            self.setCurrentEditingPhoto(value);
        });
    }

    getImage(index: number): Promise<IPhoto> {
        const self = this;
        const promise = new Promise<IPhoto>((resolve) => {
            let currentPhotosSize = self.photos.length;
            if (currentPhotosSize > index) {
                self.currentImageIndex = index;
                resolve(self.photos[index]);
            } else {
                // Try to load more images.
                self.doLoadMorePhotos().then(() => {
                    const hasNew = (currentPhotosSize % self.photos.length) !== 0;
                    if (hasNew) {
                        self.currentImageIndex = index;
                        resolve(self.photos[index]);
                    } else {
                        self.currentImageIndex = 0;
                        resolve(self.photos[0]);
                    }
                });
            }
        });

        return promise;
    }

    openModalPhoto(photo: IPhoto, $event: Event) {
        this.photoModal.config = {
            backdrop: "static"
        };

        $event.preventDefault();
        this.setCurrentEditingPhoto(photo);
        this.photoModal.show();
        this.enableKeyboardNav();
    }

    closeModalPhoto() {
        if (this.photosForm.dirty) {
            this.modalAlerts.push({ type: "warning", msg: "Du har ändringar som inte sparats. vänligen tryck på spara-knappen.", dismissOnTimeout: 5000 });
            return;
        }

        this.disableKeyboardNav();
        this.setCurrentEditingPhoto(null);
        this.photoModal.hide();
    }

    setCurrentEditingPhoto(photo: IPhoto) {
        let visible = photo !== null;
        if (visible) {
            this.addPhotoChange(photo);
        }
        
        this.currentEditingPhoto = photo;
        this.currentPhotoIsVisible = visible;
        // this.changeDetectorRef.detectChanges();
    }

    enableKeyboardNav() {
        this.enableKeybordNav = true;
    };

    disableKeyboardNav() {
        this.enableKeybordNav = false;
    };

    @HostListener("document:keyup", ["$event"])
    keybordActionKeyUp(event) {
        if (this.enableKeybordNav) {
            this.ngZone.run(() => {
                this.keyboardAction(event);
            });
        }
    }

    keyboardAction(event) {
        const keycodeEsc = 27;
        const keycodeLeftArrow = 37;
        const keycodeRightArrow = 39;

        const keycode = event.keyCode;
        if (keycode === keycodeEsc) {
            this.closeModalPhoto();
        } else if (keycode === keycodeLeftArrow) {
            this.prevPhoto();
        } else if (keycode === keycodeRightArrow) {
            this.nextPhoto();
        }
    };

    doSave() {
        if (this.profileForm.dirty === false && this.photosForm.dirty === false) {
            console.log("No changes, skiping save.");
            return;
        }

        this.ngZone.run(() => {
            if (this.profileForm.dirty) {
                let promise = this.umbracoAjaxService.post("Profile", "SaveProfilePost", this.profileForm.value)
                    .catch(() => {
                    })
                    .then((value: boolean) => {
                        if (value) {
                            // this.createProfileForm(this.id);
                        } else {
                            this.alerts.push({ type: "danger", msg: "Något gick fel." });
                        }
                    });
                this.busy.push(promise);
            }

            if (this.photosForm.dirty) {
                const changes: FormArray = <FormArray>this.photosForm.controls['photoChanges'];
                const valuesToSend = [];
                changes.controls.forEach((v) => {
                    if (v.dirty) {
                        valuesToSend.push(v.value);
                    }
                });
                
                let promise = this.umbracoAjaxService.post("Profile", "SavePhotosPost", { photoChanges: valuesToSend });
                this.busy.push(promise);

                promise.then((value: boolean) => {
                    if (value === false) {
                        this.alerts.push({ type: "danger", msg: "Något gick fel." });
                    } else {
                        changes.controls.forEach((v) => {
                            if (v.dirty) {
                                v.markAsPristine();
                            }
                        });
                    }
                    
                    // this.changeDetectorRef.detectChanges();
                });
            }
        });
    }

    doCancel() {
        this.createProfileForm(this.id);
        this.profileForm.markAsPristine();
    }

    doCancelPhotosForm() {
        this.enableKeyboardNav();
        if (this.photosPageIndex !== 1) {
            this.createOrUpdatePhotosForm(1, true);
        }
        this.photosForm.markAsPristine();
        this.isEditingPhoto = false;
    }

    doEditPhotosForm() {
        this.disableKeyboardNav();
        this.isEditingPhoto = true;
    }

    doLoadMorePhotos(): Promise<IPhoto[]> {
        if (this.hasPages()) {
            this.photosPageIndex += 1;
            let promise = this.createOrUpdatePhotosForm(this.photosPageIndex);
            this.busy.push(promise);

            return promise;
        }

        return Promise.resolve<IPhoto[]>([]);
    }
    
    createProfileForm(id: number = null) {
        const self = this;
        
        let promise: Promise<any> = new Promise((resolve, reject) => {
            if (Object.isNotNullOrUndefined(id)) {
                let getProfilePromise = self.umbracoAjaxService.post("Profile", "GetProfilePost", { id: id }).catch(reject).then((value: any) => {
                    self.profile = value;
                    resolve(value);
                });
                this.busy.push(getProfilePromise);
            } else {
                resolve(self.profile);
            }
        });

        promise.then(value => {
            this.profileForm = this.formBuilder.group({
                name: [value.user.name],
                email: [value.user.email],
                aboutMe: [value.user.aboutMe],
                bio: [value.user.bio],
                memberField: [value.user.memberField]
            });
            this.avatarForm = this.formBuilder.group({
                avatarUrl: [value.user.avatar]
            });
        });

        return promise;
    }

    createOrUpdatePhotosForm(page: number = null, reset: boolean = false) {
        const self = this;
        let fetch = page !== null;

        if (fetch && Object.isNotNullOrUndefined(self.photosTotalPages) && self.photosTotalPages > page) {
            fetch = false;
        }

        let promise: Promise<IPhoto[]> = new Promise((resolve, reject) => {
            if (fetch) {
                let getPhotosPromise = self.umbracoAjaxService.post("Profile", "GetPhotosPost", { page: page, pageSize: 25, id: self.id }).catch(reject).then((value: IGetPhotosPayload) => {
                    self.photosTotalPages = value.totalPages;
                    
                    if (Object.isNullOrUndefined(self.photos)) {
                        self.photos = value.items;
                    } else {
                        self.photos = _(self.photos) // start sequence
                            .keyBy('id') // create a dictionary of the 1st array
                            .merge(_.keyBy(value.items, 'id')) // create a dictionary of the 2nd array, and merge it to the 1st
                            .values() // turn the combined dictionary to array
                            .value(); // get the value (array) out of the sequence
                    }

                    const diff = _.differenceBy(self.photos, value.items, "id");
                    if (diff.length) {
                        resolve(diff);
                    } else {
                        resolve(self.photos);
                    }
                });
                this.busy.push(getPhotosPromise);
            } else {
                resolve(self.photos);
            }
        });

        promise.then((value: IPhoto[]) => {
            if (reset || Object.isNullOrUndefined(self.photosForm)) {
                self.photoChanges = [];
                self.photosForm = self.formBuilder.group({
                    photoChanges: self.formBuilder.array([])
                });
            }

            if (value) {
                value.forEach((photo: IPhoto) => {
                    self.addPhotoChange(photo);
                });
            }
        });

        return promise;
    }

    ngOnChanges(changes: SimpleChanges): void {
        super.ngOnChanges(changes);
    }

    ngAfterContentInit(): void {
        this.ngZone.run(() => {
            this.uploader.onSuccessItem = (item: FileItem, response: string, status: number, headers: ParsedResponseHeaders) => {
                let files: IPhoto[] = JSON.parse(response);
                files.forEach((photo) => {
                    this.photos.unshift(photo);
                    this.addPhotoChange(photo);
                });
                this.setCurrentEditingPhoto(null);
            };

            const cssImportPromise = System.import("./profile.scss");
            const profileFormPromise = this.createProfileForm(this.id);
            const photosFormPromise = this.createOrUpdatePhotosForm(1);
            const getPreValues = this.umbracoAjaxService.post("Profile", "GetPhotoPrevaluesPost").then(value => {
                this.hairColors = value.hairColor;
                this.hairLengths = value.hairLength;
                this.colorTypes = value.colorType;
                this.textures = value.texture;
            });

            Promise.all([cssImportPromise, profileFormPromise, photosFormPromise, getPreValues]).then(() => {
                this.viewState = enums.DefaultViewState.DefaultTemplate;
            });
        });
    }
    
    ngOnInit(): void {
        this.viewState$ = enums.DefaultViewState.None;
    }
}

﻿import { Component, Inject, Input, NgZone, ViewContainerRef, ChangeDetectorRef, Renderer, OnInit } from "@angular/core";
import { LoginEventService, LoginEventType } from "../../loginEvent.service";
import { IMemberPayload } from "../../abstraction/IMemberPayload";
import * as enums from "../../enums/";
import { TemplateBaseComponent } from "../abstraction/TemplateBaseComponent";
import { Protected } from "../../decorators/Protected";
import * as bl from "../../blueleet";

// @Protected
@Component({
    selector: "signout",
    template: `<template [ngTemplateOutlet]="this.currentTemplate" [ngOutletContext]="{ $implicit: this }"></template>`,
    styles: [require("./signout.scss").toString()]
})
export class SignoutComponent extends TemplateBaseComponent implements OnInit {
    viewState$: enums.DefaultViewState = enums.DefaultViewState.DefaultTemplate;
    model: IMemberPayload;

    constructor(
        @Inject(ChangeDetectorRef) changeDetectorRef: ChangeDetectorRef,
        @Inject(ViewContainerRef) viewContainer: ViewContainerRef,
        @Inject(NgZone) protected ngZone: NgZone,
        @Inject(Renderer) protected renderer: Renderer,
        @Inject(bl.UmbracoAjaxService) protected umbracoAjaxService: bl.UmbracoAjaxService) {
        super(changeDetectorRef, viewContainer);
    }

    signout() {
        this.ngZone.run(() => {
            this.umbracoAjaxService.post("MemberSurface", "SignOutPost").then((value: IMemberPayload) => {
                window.location.href = value.loginUrl;
            });
        });
    }

    ngOnInit(): void {
        this.ngZone.run(() => {
            this.umbracoAjaxService.post("MemberSurface", "GetMemberPost").then(value => {
                this.model = value;
            });
        });
    }
}

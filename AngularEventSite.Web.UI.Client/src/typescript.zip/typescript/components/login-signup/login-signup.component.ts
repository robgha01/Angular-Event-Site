﻿import { Component, Inject, NgZone, QueryList, ContentChildren, ContentChild, TemplateRef, ViewContainerRef, Renderer, OnInit, AfterContentInit } from "@angular/core";
import { LoginEventService, LoginEventType } from "../../loginEvent.service";
import { BootstrapFormInputComponent } from "../bootstrap/form-input.component";
import { UserService } from "../../user.service";
import { IMemberPayload as MemberPayload } from "../../abstraction/IMemberPayload";
import { GenericMessages } from "../../enums/generic-messages-enum";
import { MemberStatus } from "../../enums/member-status-enum";
import * as bl from "../../blueleet";
import {IPayload as Payload} from "../../abstraction/IPayload";

export enum LoginSignupViewState {
    None,
    LoginTemplate,
    SignupTemplate,
    ForgotPasswordTemplate
}

@Component({
    selector: "login-signup",
    template: `<template [ngTemplateOutlet]="this.currentTemplate" [ngOutletContext]="{ $implicit: this }"></template>`,
    styles: [require("./login-signup.scss").toString()]
})
export class LoginSignupComponent implements OnInit, AfterContentInit {
    @ContentChild("Login") loginTemplate: TemplateRef<any>;
    @ContentChild("Signup") signupTemplate: TemplateRef<any>;
    @ContentChild("ForgotPassword") forgotPasswordTemplate: TemplateRef<any>;
    @ContentChildren(BootstrapFormInputComponent, { descendants: true }) vc: QueryList<BootstrapFormInputComponent>;
    viewState$: LoginSignupViewState = LoginSignupViewState.LoginTemplate;

    get viewState() {
        return this.viewState$;
    }

    set viewState(value: LoginSignupViewState) {
        this.viewState$ = value;
        this.currentTemplate = this.getTemplate();
    }

    currentTemplate: TemplateRef<any>;

    constructor(
        @Inject(NgZone) protected ngZone: NgZone,
        @Inject(ViewContainerRef) protected viewContainerRef: ViewContainerRef,
        @Inject(Renderer) protected renderer: Renderer,
        @Inject(LoginEventService) protected loginEventService: LoginEventService,
        @Inject(UserService) protected userService: UserService,
        @Inject(bl.UmbracoAjaxService) private umbracoAjaxService: bl.UmbracoAjaxService) {
    }

    getTemplate(): TemplateRef<any> {
        switch (this.viewState) {
            case LoginSignupViewState.LoginTemplate:
                return this.loginTemplate;
            case LoginSignupViewState.SignupTemplate:
                return this.signupTemplate;
            case LoginSignupViewState.ForgotPasswordTemplate:
                return this.forgotPasswordTemplate;
            default:
                return null;
        }
    }

    showLogin($event: Event): void {
        $event.preventDefault();
        this.ngZone.run(() => {
            this.viewState = LoginSignupViewState.LoginTemplate;
            console.log(this.vc);
        });
    }

    showSignup($event: Event): void {
        $event.preventDefault();
        this.ngZone.run(() => {
            this.viewState = LoginSignupViewState.SignupTemplate;
            console.log(this.vc);
        });
    }

    showForgotPassword($event: Event): void {
        $event.preventDefault();
        this.ngZone.run(() => {
            this.viewState = LoginSignupViewState.ForgotPasswordTemplate;
        });
    }

    ngAfterContentInit(): void {
        this.userService.getMember().catch((reason: MemberPayload) => {
            if (reason.status === MemberStatus.LoginExpired) {
                this.currentTemplate = this.getTemplate();
                this.vc.changes.subscribe((value: BootstrapFormInputComponent) => {
                });
            }
        }).then((value: MemberPayload) => {
            if (value && value.messageType === GenericMessages.Success) {
                window.location.href = "/";
            }
        });
    }

    ngOnInit(): void {
        const forgotPassToken = Object.getQueryStringValue("token");
        if (!Object.isNullOrUndefined(forgotPassToken)) {
            this.viewState = LoginSignupViewState.ForgotPasswordTemplate;
        }

        this.loginEventService.on(LoginEventType.None).subscribe((): void => {
            this.viewState = LoginSignupViewState.None;
        });
        this.loginEventService.on(LoginEventType.Success).subscribe((): void => {
            this.viewState = LoginSignupViewState.None;
        });
        this.loginEventService.on(LoginEventType.ShowLoginView).subscribe((): void => {
            this.viewState = LoginSignupViewState.LoginTemplate;
        });
        this.loginEventService.on(LoginEventType.ShowSignupView).subscribe((): void => {
            this.viewState = LoginSignupViewState.SignupTemplate;
        });
        this.loginEventService.on(LoginEventType.ShowForgotPasswordView).subscribe((): void => {
            this.viewState = LoginSignupViewState.ForgotPasswordTemplate;
        });
    }
}

﻿import { Component } from "@angular/core";

/**
 * <ng-content></ng-content> : This copies everyting inside the component to the location of ng-content.
 */

@Component({
    selector: "course-calendar",
    template: "<div class=\"course-calendar\"><ng-content></ng-content></div>"
})
export class CourseCalendarComponent { }

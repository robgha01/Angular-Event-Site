﻿export interface IQuickNavigatorMenuItem {
    Name: string;
    Url: string;
    Target: string;
}

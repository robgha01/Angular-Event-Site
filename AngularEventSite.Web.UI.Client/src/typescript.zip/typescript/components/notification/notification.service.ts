﻿import { Injectable, Inject, NgZone } from "@angular/core";
import * as Rx from "rxjs/Rx";
import * as bl from "../../blueleet";
import * as enums from "../../enums/";
const _ = require("lodash");

@Injectable()
export class NotificationService {
    public onNotificationsChange: Rx.BehaviorSubject<IPagedResult<INotification>> = new Rx.BehaviorSubject(new PagedNotificationResult());

    constructor( @Inject(bl.UmbracoAjaxService) private umbracoAjaxService: bl.UmbracoAjaxService) {  }

    public updateNotifications(memberId: number): Promise<any> {
        return new Promise((resolve, reject) => {
            return this.umbracoAjaxService.post("Notification", "GetNotificationsPost", { memberId: memberId })
                .catch((value) => {
                    reject(value);
                    this.onNotificationsChange.error(value);
                })
                .then((value: IPagedResult<INotification>) => {
                    // No participants.
                    if (_.isEmpty(value.items) && _.isEmpty(this.onNotificationsChange.value.items) === false) {
                        resolve(new PagedNotificationResult());
                        this.onNotificationsChange.next(new PagedNotificationResult());
                    } else if (_.isEmpty(value.items) === false && _.isEmpty(this.onNotificationsChange.value.items) === false) {
                        var diff = _(value).differenceBy(this.onNotificationsChange.value.items, "memberId").value(); // Filter out the already existing items.
                        if (_.isEmpty(diff)) {
                            console.log("updateNotifications => No changes.");
                            // No changes
                            resolve();
                            return;
                        }
                    }
                    
                    resolve(value);
                    this.onNotificationsChange.next(value);
                });
        });
    }

    public removeNotification(memberId: number, notification: INotification): Promise<any> {
        return new Promise((resolve, reject) => {
            return this.umbracoAjaxService.post("Notification", "RemoveNotificationPost", { memberId: memberId, messageId: notification.messageId })
                .catch((value) => {
                    reject(value);
                    this.onNotificationsChange.error(value);
                }).then(value => {
                    resolve(value);

                    const index = this.onNotificationsChange.value.items.indexOf(notification);
                    if (index !== -1) {
                        const res = this.onNotificationsChange.value;
                        res.items.splice(index, 1);
                        this.onNotificationsChange.next(res);
                    }
                });
        });
    }

    public removeAllNotifications(memberId: number): Promise<any> {
        return new Promise((resolve, reject) => {
            return this.umbracoAjaxService.post("Notification", "RemoveAllNotificationsPost", { memberId: memberId })
                .catch((value) => {
                    reject(value);
                    this.onNotificationsChange.error(value);
                }).then(value => {
                    resolve(value);
                    this.onNotificationsChange.next(null);
                });
        });
    }
}

export class PagedNotificationResult implements IPagedResult<INotification> {
    items: INotification[] = [];
    pageNumber: number;
    totalPages: number;
}

export interface INotification {
    messageId: number;
    message: string;
    createDate: Date;
    fromMember: any;
    toMember: any;
}

export interface IPagedResult<TEntity> {
    items: TEntity[];
    pageNumber: number;
    totalPages: number;
}

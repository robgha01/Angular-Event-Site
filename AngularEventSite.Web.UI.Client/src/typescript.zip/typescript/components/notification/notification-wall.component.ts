﻿import { Component, Inject, NgZone, Input, ElementRef, ViewChild, ContentChild, ChangeDetectorRef, TemplateRef, ViewContainerRef, OnInit, AfterViewInit, ChangeDetectionStrategy } from "@angular/core";
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import { ModalDirective } from "ng2-bootstrap/modal";
import { TemplateBaseComponent } from "../abstraction/TemplateBaseComponent";
import * as bl from "../../blueleet";
import * as enums from "../../enums/";
import { UserService } from "../../user.service";
import { NotificationService, INotification, PagedNotificationResult } from "./notification.service";
const _ = require("lodash");

@Component({
    selector: "notification-wall",
    template: require("./templates/notification-wall.html"),
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [NotificationService]
})
export class NotificationWallComponent extends TemplateBaseComponent implements OnInit, AfterViewInit {
    @ViewChild("DefaultTemplate") defaultTemplate: TemplateRef<any>;
    @ViewChild("notesModal") public notesModal: ModalDirective;
    @ContentChild("ContentTemplat") contentTemplate: TemplateRef<any>;
    @ContentChild("ModalHeaderTemplat") modalHeaderTemplat: TemplateRef<any>;
    @ContentChild("ModalContentTemplat") modalContentTemplat: TemplateRef<any>;

    @Input() memberId: number;
    @Input() updateInterval: number = 5000;
    @Input() waitMessage: string = "...";
    @Input() modalHeader: string = "";

    notifications: PagedNotificationResult = new PagedNotificationResult();
    isUpdating: boolean = false;
    busy: Promise<any>[] = [];
    
    constructor(
        @Inject(ChangeDetectorRef) changeDetectorRef: ChangeDetectorRef,
        @Inject(ViewContainerRef) viewContainer: ViewContainerRef,
        @Inject(NgZone) private ngZone: NgZone,
        @Inject(bl.UmbracoAjaxService) private umbracoAjaxService: bl.UmbracoAjaxService,
        @Inject(UserService) public userService: UserService,
        @Inject(NotificationService) private notificationService: NotificationService
    ) {
        super(changeDetectorRef, viewContainer);
    }

    openModalNotes($event: Event) {
        $event.preventDefault();

        if (this.hasNotifications() === false) {
            return;
        }

        this.notesModal.config = {
            backdrop: true,
            keyboard: true
        };
        
        this.notesModal.show();
    }

    hasNotifications(): boolean {
        return !_.isEmpty(this.notifications);
    }

    removeNotification(notification: INotification) {
        this.notificationService.removeNotification(this.memberId, notification);
    }

    removeAllNotifications() {
        this.notificationService.removeAllNotifications(this.memberId);
    }

    closeModalNotes() {
        this.notesModal.hide();
    }

    ngAfterViewInit(): void {
        this.notificationService.onNotificationsChange.subscribe(value => {
            if (_.isEmpty(value.items)) {
                if (this.hasNotifications()) {
                    this.notifications = new PagedNotificationResult();
                    this.changeDetectorRef.markForCheck();
                }

                return;
            }

            this.notifications = value;
            this.changeDetectorRef.markForCheck();
        });

        setInterval(() => {
            this.updateState();
        }, this.updateInterval);
    }

    updateState() {
        if (this.isUpdating) {
            return;
        }

        this.isUpdating = true;
        this.notificationService.updateNotifications(this.memberId).then(() => {
            this.isUpdating = false;
        });
    }

    ngOnInit(): void {
        System.import("./notification-wall.scss");
        this.viewState$ = enums.DefaultViewState.DefaultTemplate;
    }
}

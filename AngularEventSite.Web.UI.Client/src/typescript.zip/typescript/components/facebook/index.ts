﻿import { FacebookLoginComponent } from "./facebook-login.component";
import { FacebookLoginCompleteComponent } from "./facebook-login-complete.component";

export const facebookComponents = [
    FacebookLoginComponent,
    FacebookLoginCompleteComponent
];

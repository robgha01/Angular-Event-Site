﻿import { Component, Inject, ContentChild, ChangeDetectorRef, ViewContainerRef, OnInit, NgZone, TemplateRef } from "@angular/core";
import { FacebookService } from "ng2-facebook-sdk/dist";
import { IMemberPayload as MemberPayload } from "../../abstraction/IMemberPayload";
import { LoginEventService, LoginEventType } from "../../loginEvent.service";
import * as enums from "../../enums/";
import { TemplateBaseComponent } from "../abstraction/TemplateBaseComponent";

export enum FacebookLoginCompleteViewState {
    None,
    RegisteredTemplate,
    NeedApprovalTemplate
}

@Component({
    selector: "facebook-login-complete",
    template: `<template [ngTemplateOutlet]="this.currentTemplate" [ngOutletContext]="{ $implicit: this.user }"></template>`,
    viewProviders: [FacebookService]
})
export class FacebookLoginCompleteComponent extends TemplateBaseComponent implements OnInit {
    @ContentChild("Registered") registeredTemplate: TemplateRef<any>;
    @ContentChild("NeedApproval") needApprovalTemplate: TemplateRef<any>;
    user: any = {};
    status: enums.MemberStatus;
    viewState$: FacebookLoginCompleteViewState = FacebookLoginCompleteViewState.None;

    constructor(
        @Inject(ChangeDetectorRef) changeDetectorRef: ChangeDetectorRef,
        @Inject(ViewContainerRef) viewContainer: ViewContainerRef,
        @Inject(NgZone) protected ngZone: NgZone,
        @Inject(LoginEventService) protected loginEventService: LoginEventService) {
        super(changeDetectorRef, viewContainer);
    }

    getTemplate(): TemplateRef<any> {
        if (Object.isNullOrUndefined(this.registeredTemplate)) {
            this.registeredTemplate = null;
        }
        if (Object.isNullOrUndefined(this.needApprovalTemplate)) {
            this.needApprovalTemplate = null;
        }
        switch (this.viewState) {
            case FacebookLoginCompleteViewState.NeedApprovalTemplate:
                return this.needApprovalTemplate;
            case FacebookLoginCompleteViewState.RegisteredTemplate:
                return this.registeredTemplate;
            default:
                return null;
        }
    }

    userLoggedIn(payload: MemberPayload): void {
        this.ngZone.run(() => {
            this.status = payload.status;
            this.user.name = payload.user.name;

            if (!Object.isNullOrUndefined(this.status) && this.status === enums.MemberStatus.Registered) {
                this.viewState = FacebookLoginCompleteViewState.RegisteredTemplate;
            } else if (!Object.isNullOrUndefined(this.needApprovalTemplate) && !Object.isNullOrUndefined(this.status) && this.status === enums.MemberStatus.NeedApproval) {
                this.viewState = FacebookLoginCompleteViewState.NeedApprovalTemplate;
            } else {
                this.viewState = FacebookLoginCompleteViewState.None;
            }
        });
    }

    ngOnInit(): void {
        this.loginEventService.on(LoginEventType.Success).subscribe(x => this.userLoggedIn(x));
    }
}

﻿import { Component, Inject, OnInit, NgZone, ChangeDetectorRef, ViewContainerRef, ContentChild, ViewChild, TemplateRef, EmbeddedViewRef } from "@angular/core";
import { FacebookService, FacebookLoginResponse, FacebookInitParams } from "ng2-facebook-sdk/dist";
import * as $script from "scriptjs";
import * as bl from "../../blueleet";
import { IMemberPayload as MemberPayload } from "../../abstraction/IMemberPayload";
import { LoginEventService, LoginEventType } from "../../loginEvent.service";
import * as enums from "../../enums/";
import { TemplateBaseComponent } from "../abstraction/TemplateBaseComponent";

export enum FacebookLoginViewState {
    ButtonTemplate,
    LoginCompleteTemplate,
    ErrorTemplate
}

@Component({
    selector: "facebook-login",
    template: `<template [ngTemplateOutlet]="this.currentTemplate" [ngOutletContext]="{ $implicit: this }"></template>
               <template #GenericFacebookError let-fb>
                    <p>Unable to perform the task:</p>
                    <span>{{ fb.payload.message }}</span>
               </template>
              `,
    viewProviders: [FacebookService]
})
export class FacebookLoginComponent extends TemplateBaseComponent implements OnInit {
    @ViewChild("GenericFacebookError") genericFacebookErrorTemplate: TemplateRef<any>;
    @ContentChild("FacebookError") facebookErrorTemplate: TemplateRef<any>;
    @ContentChild("FacebookButton") facebookButtonTemplate: TemplateRef<any>;

    facebookButtonTemplateViewRef: EmbeddedViewRef<any>;
    viewState$: FacebookLoginViewState = FacebookLoginViewState.ButtonTemplate;
    user: any;
    memberStatus = enums.MemberStatus;
    status: enums.MemberStatus;
    payload: MemberPayload;

    constructor(
        @Inject(ChangeDetectorRef) changeDetectorRef: ChangeDetectorRef,
        @Inject(ViewContainerRef) viewContainer: ViewContainerRef,
        @Inject(NgZone) protected ngZone: NgZone,
        @Inject(FacebookService) protected facebookService: FacebookService,
        @Inject(bl.ConfigService) protected configService: bl.ConfigService,
        @Inject(bl.UmbracoAjaxService) protected umbracoAjaxService: bl.UmbracoAjaxService,
        @Inject(LoginEventService) protected loginEventService: LoginEventService) {
        super(changeDetectorRef, viewContainer);
    }

    getTemplate(): TemplateRef<any> {
        let template: TemplateRef<any> = null;
        switch (this.viewState) {
            case FacebookLoginViewState.LoginCompleteTemplate:
                break;
            case FacebookLoginViewState.ErrorTemplate:
                if (this.facebookErrorTemplate) {
                    template = this.facebookErrorTemplate;
                } else {
                    template = this.genericFacebookErrorTemplate;
                }
                break;
            default:
                template = this.facebookButtonTemplate;
        }

        return template;
    }

    facebookLogin($event: Event) {
        $event.preventDefault();
        let self = this;
        this.viewState = FacebookLoginViewState.ButtonTemplate;
        this.facebookService.login({ scope: "email,user_birthday,public_profile", return_scopes: true })
            .then(
            (response: FacebookLoginResponse) => {
                this.ngZone.run(() => {
                    this.umbracoAjaxService.post("Facebook", "LoginPost", { accessToken: response.authResponse.accessToken })
                        .catch((payload: MemberPayload) => {
                            this.user = undefined;
                            this.payload = payload;
                            this.status = this.payload.status;
                            this.viewState = FacebookLoginViewState.ErrorTemplate;
                            this.loginEventService.emit(LoginEventType.GenericError, payload);
                        })
                        .then((payload: MemberPayload) => {
                            if (payload.messageType === enums.GenericMessages.Success) {
                                self.user = payload.user;
                                this.loginEventService.emit(LoginEventType.Success, payload);
                                this.viewState = FacebookLoginViewState.LoginCompleteTemplate;
                            }
                        });
                });
            },
            (error: any) => console.error(error));
    }

    ngOnInit(): void {
        this.configService.ensureConfigs()
            .then(configs => {
                $script("https://connect.facebook.net/en_US/sdk.js",
                    () => {
                        let fbParams: FacebookInitParams = {
                            appId: configs["FacebookAppId"],
                            version: configs["FacebookApiVersion"],
                            xfbml: true,
                            cookie: true
                        };
                        this.facebookService.init(fbParams);
                    });
            });
    }
}

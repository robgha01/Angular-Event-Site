﻿import { Component, Inject, ChangeDetectionStrategy, NgZone, HostListener, Input, SecurityContext, ElementRef, QueryList, ViewChild, ContentChild, ContentChildren, ChangeDetectorRef, TemplateRef, ViewContainerRef, OnInit, AfterViewInit, AfterContentInit, OnChanges, SimpleChanges, ViewChildren } from "@angular/core";
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import { Response } from "@angular/http";
import { DomSanitizer } from "@angular/platform-browser";
import { TemplateBaseComponent } from "../abstraction/TemplateBaseComponent";
import { FileUploader, FileItem, ParsedResponseHeaders } from "ng2-file-upload";
import { ModalDirective } from "ng2-bootstrap/modal";
import { IMemberPayload } from "../../abstraction/IMemberPayload";
import { InlineEditorGroupComponent, InlineEditorState } from "../../blueleet/modules/inline-editor/inline-editor-group.component";
import * as bl from "../../blueleet";
import * as enums from "../../enums/";
import * as $ from "jquery";
import * as Rx from "rxjs/Rx";
import * as Profilecomponent from "../profile/profile.component";
const _ = require("lodash");

export interface IfilterForm {
    all: boolean;
    hairColors: boolean[];
    hairLengths: boolean[];
    colorTypes: boolean[];
    textures: boolean[];
}

@Component({
    selector: "image-wall",
    template: require("./templates/image-wall.html")
})
export class ImageWallComponent extends TemplateBaseComponent implements OnInit, AfterContentInit {
    @ViewChild("DefaultTemplate") defaultTemplate: TemplateRef<any>;
    hairColors: string[];
    hairLengths: string[];
    colorTypes: string[];
    textures: string[];
    photos: Profilecomponent.IPhoto[];

    filterForm: FormGroup;

    constructor(
        @Inject(ChangeDetectorRef) changeDetectorRef: ChangeDetectorRef,
        @Inject(ViewContainerRef) viewContainer: ViewContainerRef,
        @Inject(NgZone) private ngZone: NgZone,
        @Inject(FormBuilder) private formBuilder: FormBuilder,
        @Inject(FormBuilder) private sanitizer: DomSanitizer,
        @Inject(bl.UmbracoAjaxService) private umbracoAjaxService: bl.UmbracoAjaxService
    ) {
        super(changeDetectorRef, viewContainer);
    }

    getFilterLabel(items: string[], index: number) {
        return items[index];
    }

    getSizedUrl(photo: Profilecomponent.IPhoto, width: number): string {
        return `${photo.url}?width=${width}`;
    }

    ngAfterContentInit(): void {
        this.ngZone.run(() => {
            const cssImportPromise = System.import("./image-wall.scss");
            const getPreValues = this.umbracoAjaxService.post("Profile", "GetPhotoPrevaluesPost").then(value => {
                this.hairColors = value.hairColor;
                this.hairLengths = value.hairLength;
                this.colorTypes = value.colorType;
                this.textures = value.texture;
            });

            Promise.all([cssImportPromise, getPreValues]).then(() => {
                this.filterForm = this.formBuilder.group({
                    all: [],
                    hairColors: this.formBuilder.array([]),
                    hairLengths: this.formBuilder.array([]),
                    colorTypes: this.formBuilder.array([]),
                    textures: this.formBuilder.array([])
                });

                this.ngZone.run(() => {
                    this.umbracoAjaxService.post("ImageWall", "FilterPhotosPost", { all: true })
                        .then((res: any) => {
                            console.log(res);
                            this.photos = res;
                        });
                });

                const controlAll = <FormGroup>this.filterForm.controls["all"];

                const controlHairColors = <FormArray>this.filterForm.controls['hairColors'];
                this.hairColors.forEach((value) => {
                    controlHairColors.push(this.formBuilder.control(false)); 
                });

                const controlHairLengths = <FormArray>this.filterForm.controls['hairLengths'];
                this.hairLengths.forEach((value) => {
                    controlHairLengths.push(this.formBuilder.control(false));
                });

                const controlColorTypes = <FormArray>this.filterForm.controls['colorTypes'];
                this.colorTypes.forEach((value) => {
                    controlColorTypes.push(this.formBuilder.control(false));
                });

                const controlTextures = <FormArray>this.filterForm.controls['textures'];
                this.textures.forEach((value) => {
                    controlTextures.push(this.formBuilder.control(false));
                });

                controlAll.valueChanges.subscribe((value: boolean) => {
                    if (value) {
                        controlHairColors.reset(false, { onlySelf: true, emitEvent: false });
                        controlHairLengths.reset(false, { onlySelf: true, emitEvent: false });
                        controlColorTypes.reset(false, { onlySelf: true, emitEvent: false });
                        controlTextures.reset(false, { onlySelf: true, emitEvent: false });

                        if (this.filterForm.dirty === false) {
                            return;
                        }

                        this.ngZone.run(() => {
                            this.umbracoAjaxService.post("ImageWall", "FilterPhotosPost", { all: true })
                                .then((res: any) => {
                                    console.log(res);
                                    this.photos = res;
                                });
                        });
                    }
                });
                
                this.filterForm.valueChanges.debounceTime(500).subscribe((v: IfilterForm) => {
                    let result = { hairColors: [], hairLengths: [], colorTypes: [], textures: [] }

                    result.hairColors = _.zipWith(this.hairColors, v.hairColors, (value, enabled) => ({ value, enabled }));
                    result.hairColors = _.map(_.filter(result.hairColors, o => o.enabled), "value");

                    result.hairLengths = _.zipWith(this.hairLengths, v.hairLengths, (value, enabled) => ({ value, enabled }));
                    result.hairLengths = _.map(_.filter(result.hairLengths, o => o.enabled), "value");

                    result.colorTypes = _.zipWith(this.colorTypes, v.colorTypes, (value, enabled) => ({ value, enabled }));
                    result.colorTypes = _.map(_.filter(result.colorTypes, o => o.enabled), "value");

                    result.textures = _.zipWith(this.textures, v.textures, (value, enabled) => ({ value, enabled }));
                    result.textures = _.map(_.filter(result.textures, o => o.enabled), "value");

                    this.ngZone.run(() => {
                        this.umbracoAjaxService.post("ImageWall", "FilterPhotosPost", result)
                            .then((res: any) => {
                                console.log(res);
                                this.photos = res;
                            });
                    });
                });
                
                this.viewState = enums.DefaultViewState.DefaultTemplate;
            });
        });
    }
    
    ngOnInit(): void {
        this.viewState$ = enums.DefaultViewState.None;
    }
}

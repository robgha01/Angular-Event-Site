﻿import { NgModule, APP_INITIALIZER } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { HttpModule } from "@angular/http";
import { ReactiveFormsModule } from "@angular/forms";
import { FileUploadModule } from "ng2-file-upload";
import * as ng2Busy from "angular2-busy";

// ToDo: seperate below code into own modules and import for better readability.

// Valor imports
import { AlertModule } from "ng2-bootstrap/alert";
import { ModalModule } from "ng2-bootstrap/modal";
import { ButtonsModule } from "ng2-bootstrap/buttons";
import { PopoverModule } from "ng2-bootstrap/popover";

// Application specific imports
import { AppComponent } from "./main.app";
import { AffixDirective } from "./affix.directive";
import { IconColorDirective } from "./icon-color.directive";
import { LogPipe } from "./log.pipe";
import { DetectDeviceService } from "./detectDevice.service";
import { WidgetSearchDirective } from "./widget-search.directive";
import { BlueLeetUmbracoModule } from "./blueleet/blueleet-umbraco.module";
import { WidgetQuickNavigatorComponent } from "./components/widget-quickNavigator/widget-quickNavigator.component";
import { facebookComponents } from "./components/facebook/";
import { LoginSignupComponent } from "./components/login-signup/login-signup.component";
import { LoginEventService, LoginEventType } from "./loginEvent.service";
import { LoginSignupCompleteComponent } from "./components/login-signup/login-signup-complete.component";
import { SearchBoxComponent } from "./components/search-box/search-box.component";
import { SimpleLoginComponent } from "./components/simple-login/simple-login.component";
import { UserService } from "./user.service";
import { UmbracoAjaxService } from "./blueleet/umbraco-ajax-Service";
import { SimpleSignUpComponent } from "./components/simple-signup/simple-signup.component";
import { BootstrapFormInputComponent } from "./components/bootstrap/form-input.component";
import { BootstrapAlertBoxComponent } from "./components/bootstrap/alert-box/alert-box.component";
import { ValidationService } from "./validation.service";
import { ForgotPasswordComponent } from "./components/forgot-password/forgot-password.component";
import { ProfileComponent } from "./components/profile/profile.component";
import { SignoutComponent } from "./components/login-signup/signout.component";
import { MemberStatus } from "./enums/member-status-enum";
import { AlertBoxService } from "./alert-box.service";
import { InlineEditorModule } from "./blueleet/modules/inline-editor/module";
import { HoverableGroupDirective, HoverableDirective } from "./hoverable.directive";
import { HoverableEventService } from "./hoverableEvent.service";
import { IfAdminDirective, IfAdminAndDirective } from "./if-admin.directive";
import { ImageWallComponent } from "./components/image-wall/image-wall.component";
import { CourseComponent } from "./components/course/course.component";
import { ParticipantsComponent } from "./components/course/participants.component";
import { NotificationWallComponent } from "./components/notification/notification-wall.component";

@NgModule({
    imports: [
        BrowserModule,
        HttpModule,
        ReactiveFormsModule,
        FileUploadModule,
        ng2Busy.BusyModule,
        BlueLeetUmbracoModule.forRoot(),
        InlineEditorModule.forRoot(),
        AlertModule.forRoot(),
        ModalModule.forRoot(),
        ButtonsModule.forRoot(),
        PopoverModule.forRoot()
    ],
    declarations: [
        LogPipe,
        AppComponent,
        AffixDirective,
        HoverableGroupDirective,
        HoverableDirective,
        IconColorDirective,
        WidgetSearchDirective,
        IfAdminDirective,
        IfAdminAndDirective,
        WidgetQuickNavigatorComponent,
        facebookComponents,
        LoginSignupComponent,
        LoginSignupCompleteComponent,
        SimpleLoginComponent,
        SimpleSignUpComponent,
        ForgotPasswordComponent,
        SearchBoxComponent,
        BootstrapFormInputComponent,
        BootstrapAlertBoxComponent,
        ProfileComponent,
        SignoutComponent,
        ImageWallComponent,
        CourseComponent,
        ParticipantsComponent,
        NotificationWallComponent
    ],
    providers: [
        { provide: Window, useValue: window },
        DetectDeviceService,
        UserService,
        LoginEventService,
        AlertBoxService,
        ValidationService,
        HoverableEventService,
        {
            // Ensure that the current user if any has access to this loaded page
            provide: APP_INITIALIZER,
            useFactory: (userService: UserService, umbracoAjaxService: UmbracoAjaxService, loginEventService: LoginEventService) => () => appInializer(userService, umbracoAjaxService, loginEventService),
            deps: [UserService, UmbracoAjaxService, LoginEventService],
            multi: true
        }
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }

export function appInializer(userService: UserService, umbracoAjaxService: UmbracoAjaxService, loginEventService: LoginEventService): Promise<any> {
    loginEventService.on(LoginEventType.Success).subscribe((value) => {
        if (value.user || value.status === MemberStatus.AdminLoggedIn) {
            if (!Object.isNullOrUndefined(value.redirectToProfilePage)) {
                window.location.href = value.redirectToProfilePage;
            } else {
                umbracoAjaxService.post("MemberSurface", "GetLoginUrlPost").then(url => {
                    if (window.location.pathname.replace(new RegExp("/$"), "") !== url.replace(new RegExp("/$"), "")) {
                        window.location.reload();
                    } else {
                        window.location.href = "/";
                    }
                });
            }
        }
    });

    return new Promise((resolve) => {
        userService.hasAccess().then(value => {
            if (value) {
                umbracoAjaxService.post("MemberSurface", "GetLoginUrlPost").then(url => {
                    if (window.location.pathname.replace(new RegExp("/$"), "") === url.replace(new RegExp("/$"), "")) {
                        window.location.href = "/";
                    } else {
                        resolve(value);
                    }
                });
            } else {
                resolve(value);
            }
        });
    });
}

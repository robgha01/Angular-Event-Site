﻿// Angular 2
import "@angular/platform-browser";
import "@angular/platform-browser-dynamic";
import "@angular/core";
import "@angular/common";
import "@angular/http";

// Reactive
import "rxjs";

// Other vendors for example jQuery, Lodash or Bootstrap
// You can import js, ts, css, sass
// import "angular2-cookie/core";
import "scriptjs";
import "./blueleet/extensions/ObjectExtensions";
import "./blueleet/extensions/StringExtensions";

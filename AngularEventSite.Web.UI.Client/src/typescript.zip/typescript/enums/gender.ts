﻿export enum Gender {
    /**
     * @description Male flag.
     */
    Male = 0,

    /**
     * @description Female flag.
     */
    Female = 1
}

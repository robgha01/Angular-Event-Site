﻿export enum DefaultViewState {
    None,
    DefaultTemplate
}

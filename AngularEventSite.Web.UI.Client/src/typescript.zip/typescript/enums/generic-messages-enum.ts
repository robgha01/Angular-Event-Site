﻿export enum GenericMessages {
    Warning,
    Danger,
    Success,
    Info
}

﻿import { Directive, ElementRef, Inject, Input, Renderer, OnInit } from "@angular/core";
import { FileSelectDirective, FileDropDirective, FileUploader } from "ng2-file-upload/ng2-file-upload";


@Directive({ selector: "[ImageUpload]" })
export class ImageUploadDirective implements OnInit {
    public uploader: FileUploader = new FileUploader({  });
    public hasBaseDropZoneOver: boolean = false;
    public hasAnotherDropZoneOver: boolean = false;

    constructor(
        @Inject(ElementRef) public elementRef: ElementRef,
        @Inject(Renderer) public renderer: Renderer) { }

    ngOnInit(): void {
        
    }
}

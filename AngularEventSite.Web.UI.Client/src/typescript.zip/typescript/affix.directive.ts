﻿import { Directive, ElementRef, Inject, Input, Renderer, OnInit } from "@angular/core";
import * as $ from "jquery";

@Directive({ selector: "[affix]" })
export class AffixDirective implements OnInit {
    @Input("affix-top") affixTop: string;
    @Input("affix-bottom") affixBottom: string;
    @Input("affix-explicit-highet") affixExplicitHighet: boolean = true;

    constructor( @Inject(ElementRef) public elementRef: ElementRef, @Inject(Renderer) public renderer: Renderer) { }

    ngOnInit(): void {
        let offset: any = {};
        const el = $(this.elementRef.nativeElement);

        if (this.affixExplicitHighet) {
            let parentEl = el.parent("*");

            // let height = parentEl.outerHeight(true);
            parentEl.height(186); // ToDo fix this.
        }

        if (this.affixTop) {
            offset.top = $.isNumeric(this.affixTop) ? this.affixTop : $(this.affixTop).outerHeight(true);
        }

        if (this.affixBottom) {
            offset.bottom = $.isNumeric(this.affixBottom) ? this.affixBottom : () => $(this.affixBottom).outerHeight(true);
        }

        el.affix({
            offset: offset
        });
    }
}

﻿import { Component, NgZone, Inject, ElementRef, OnInit } from "@angular/core";
import { ServiceEvent, ServiceEventType } from "../../ServiceEvent.service";
import { UmbracoAjaxService } from "../../umbraco-ajax-Service";

@Component({
    selector: "widget-quick-navigator",
    template: require("./templates/loadindicator.html")
})
export class LoadIndicatorComponent implements OnInit {


    constructor(
        @Inject(ServiceEvent) private serviceEvent: ServiceEvent,
        @Inject(NgZone) private zone: NgZone,
        @Inject(ElementRef) private elementRef: ElementRef) { }
    
    ngOnInit(): void {
        this.serviceEvent.on(ServiceEventType.RequestBegin).subscribe(() => {

        });

        this.serviceEvent.on(ServiceEventType.RequestEnd).subscribe(() => {

        });
    }
}

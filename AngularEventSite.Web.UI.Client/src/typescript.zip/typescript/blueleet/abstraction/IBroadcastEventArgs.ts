﻿export interface IBroadcastEventArgs {
    key: any;
    data?: any;
}

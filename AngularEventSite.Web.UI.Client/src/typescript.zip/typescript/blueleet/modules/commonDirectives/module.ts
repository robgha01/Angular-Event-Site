import { NgModule, ModuleWithProviders } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FocuserDirective } from "./focus.directive";

@NgModule({
    imports: [CommonModule],
    exports: [FocuserDirective],
    declarations: [FocuserDirective]
})
export class CommonDirectivesModule {}

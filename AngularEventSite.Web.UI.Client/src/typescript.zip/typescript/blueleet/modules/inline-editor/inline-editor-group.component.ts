import { Component, TemplateRef, HostListener, forwardRef, Input, OnInit, AfterContentInit, Output, EventEmitter, ElementRef, ContentChildren, ContentChild, ViewChild, Renderer, QueryList, OnChanges, SimpleChanges } from "@angular/core";
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from "@angular/forms";
import { ModalDirective } from "ng2-bootstrap";
import { InlineEditorComponent } from "./inline-editor.component";
import { InlineTextComponent } from "./editors/text/text.component";
import { FocusService } from "../commonDirectives/focus.service";
import { InlineEditorGroupContextService } from "./services/InlineEditorContext.service";
import * as Rx from "rxjs/Rx";

export enum InlineEditorState {
    Save,
    Edit,
    Cancel
}

@Component({
    selector: "button-change",
    template: `<button class="btn btn-default" (click)="this.inlineEditorGroup.edit()"><span class="fa fa-pencil"></span> <ng-content></ng-content></button>`
})
export class ButtonChangeComponent {
    @Input() inlineEditorGroup: InlineEditorGroupComponent;
}

@Component({
    selector: "inline-editor-group",
    template: require("./inline-editor-group.html"),
    providers: [FocusService, InlineEditorGroupContextService]
})
export class InlineEditorGroupComponent implements OnInit, AfterContentInit {
    @ViewChild("editGroupModal") public editGroupModal: ModalDirective;
    @ContentChildren(InlineEditorComponent, { descendants: true }) public inlineEditors: QueryList<InlineEditorComponent>;

    // Events
    @Output() public onSave: EventEmitter<any> = new EventEmitter();
    @Output() public onEdit: EventEmitter<any> = new EventEmitter();
    @Output() public onCancel: EventEmitter<any> = new EventEmitter();

    // Settings
    @Input() public disableSave: boolean = false;
    @Input() public openInModal: boolean = false;
    @Input() public visible: boolean = true;

    protected subjectStateChange: Rx.ReplaySubject<InlineEditorState> = new Rx.ReplaySubject(1);
    public stateChange: Rx.Observable<InlineEditorState> = this.subjectStateChange.asObservable();

    public editTemplates: TemplateRef<any>[] = [];

    public isEditing: boolean = false;

    constructor(protected element: ElementRef, protected renderer: Renderer, protected focusService: FocusService, protected contextGroupService: InlineEditorGroupContextService) {}

    public ngAfterContentInit(): void {
        if (this.contextGroupService.editorGroupInstance.value === null) {
            this.inlineEditors.forEach((item) => {
                item.openInModal = false;
                item.showButtons = false;
                item.showEditState = this.openInModal === false;
                item.onSave = null;
                item.onEdit = null;
                item.onCancel = null;
                item.onClick = () => { };
                if (item.editing === false && this.isEditing) {
                    item.edit();
                }
            });

            this.contextGroupService.editorGroupInstance.next(this);
        }
    }

    public ngOnInit() { }

    public onShown() {
        if (this.openInModal) {
            this.focusService.reFocus();
        }
    }

    public toggleGroupModal() {
        if (this.editGroupModal.isShown) {
            this.editGroupModal.hide();
        } else {
            this.editGroupModal.show();
        }
        this.inlineEditors.forEach((item) => {
            item.editing = this.editGroupModal.isShown;
        });
    }

    public edit() {
        this.isEditing = true;
        if (this.openInModal) {
            this.toggleGroupModal();
        } else {
            this.inlineEditors.forEach((item) => {
                item.edit();
            });
        }

        if (this.onEdit) {
            this.onEdit.emit(this);
        }

        this.subjectStateChange.next(InlineEditorState.Edit);
    }

    // Method to display the editable value as text and emit save event to host
    protected onSubmit() {
        this.isEditing = false;
        this.subjectStateChange.next(InlineEditorState.Save);
        this.onSave.emit(this);

        if (this.openInModal) {
            this.toggleGroupModal();
        }

        this.inlineEditors.forEach((item) => {
            item.onSubmit();
        });
    }

    // Method to reset the editable value
    protected cancel() {
        this.isEditing = false;
        if (this.openInModal) {
            this.toggleGroupModal();
        }

        this.inlineEditors.forEach((item) => {
            item.cancel();
        });

        if (this.onCancel) {
            this.onCancel.emit(this);
        }

        this.subjectStateChange.next(InlineEditorState.Cancel);
    }
}

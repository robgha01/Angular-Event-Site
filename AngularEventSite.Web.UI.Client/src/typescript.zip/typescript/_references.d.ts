﻿/// <reference path="./declarations/_nodeRequireExtension.d.ts"/>
/// <reference path="../../node_modules/@types/node/index.d.ts"/>
/// <reference path="../../node_modules/@types/bootstrap/index.d.ts"/>
/// <reference path="./declarations/systemjs.d.ts"/>

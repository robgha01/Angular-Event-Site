﻿import { MemberStatus } from "../enums/member-status-enum";
import { IPayload } from "./IPayload";

export interface IMemberPayload extends IPayload {
    status: MemberStatus;
    user: any;
    redirectToProfilePage?: any;
    loginUrl?: any;
}

//export interface IUser {
//    id: string,
//    name: string,
//    full
//}

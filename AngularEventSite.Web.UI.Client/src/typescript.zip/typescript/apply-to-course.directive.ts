﻿import { Directive, Inject, Input } from "@angular/core";
import * as $ from "jquery";
import * as bl from "./blueleet";
import * as enums from "./enums/";

@Directive({ selector: "[apply-to-course]" })
export class ApplyToCourseDirective {
    @Input("course-id") courseId: number;
    
    constructor( @Inject(bl.UmbracoAjaxService) private umbracoAjaxService: bl.UmbracoAjaxService ) { }

    applyCourseClick() {
        
    }
}
